//
//  AppDelegate.m
//  LINE MASHER 2
//
//  Created by のんのん on 2023/01/31.
//

#import "AppDelegate.h"




#include "n_game.c"




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonGame *n_game;

@end

@implementation AppDelegate




- (void)awakeFromNib
{
//NSLog( @"awakeFromNib" );

	// [Needed] : this position is important
	//
	//	don't put in initWithCoder

	n_mac_image_window = _window;

	[_n_game n_mac_game_init];

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

	[_n_game n_mac_game_canvas_resize:_window width:-1 height:-1];

}

- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	[_n_game NonnonLM2HighScoreWrite];

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}

}




- (void)applicationWillFinishLaunching:(NSNotification *)aNotification
{
//NSLog( @"applicationWillFinishLaunching" );
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
//NSLog( @"applicationDidFinishLaunching" );
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}




- (IBAction)NonnonHighScoreReset:(id)sender {

	[_n_game NonnonLM2HighScoreReset];

}




- (IBAction)n_lm2_menu_readme:(id)sender {

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"lm2" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}


@end
